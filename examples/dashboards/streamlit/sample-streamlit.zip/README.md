# PSA Regional Agricultural Dashboard — Streamlit

A BI dashboard for PSA AFCD crop and aquaculture data.
Demonstrates three data-source patterns: **CSV**, **Parquet**, and **PostGIS**.

## Setup

```bash
# From the streamlit/ directory
uv run python scripts/generate_data.py   # create data/crops.csv, .parquet, aquaculture.*
uv run streamlit run app.py
```

Open http://localhost:8501 in your browser.

## Data sources

| Option | How it works |
|--------|-------------|
| **CSV** | `pd.read_csv("data/crops.csv")` — simplest, good for small datasets |
| **Parquet** | `pd.read_parquet("data/crops.parquet")` — faster reads, smaller files, preserves dtypes |
| **PostGIS** | `pd.read_sql(query, sqlalchemy_engine)` — live connection to the training database |

Switch between sources in the sidebar without restarting the app.

### PostGIS connection string format

```
postgresql://username:password@host:5432/database
```

You can also set it as an environment variable so it pre-fills:

```bash
export DATABASE_URL="postgresql://psa:psa@localhost:5432/psa"
uv run streamlit run app.py
```

## Project structure

```
streamlit/
  app.py                  # main dashboard
  pyproject.toml          # uv project / dependencies
  scripts/
    generate_data.py      # generates dummy CSV & Parquet files
  data/
    crops.csv
    crops.parquet
    aquaculture.csv
    aquaculture.parquet
```

## Dashboard sections

1. **KPI cards** — total crop area, total production, aquafarm count, seaweed farm count
2. **Area by crop** (bar) + **Aquaculture breakdown** (donut)
3. **Top regions by harvested area** (stacked bar, configurable N)
4. **Production vs. area scatter** (by region & crop)
5. **Summary table** — sortable, filterable
