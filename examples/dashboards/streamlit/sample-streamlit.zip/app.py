"""
PSA Regional Agricultural Dashboard — Streamlit
================================================
Demonstrates three data-source patterns:
  • CSV          — pd.read_csv()
  • Parquet      — pd.read_parquet()
  • PostGIS/SQL  — pd.read_sql() via SQLAlchemy (requires DATABASE_URL env var)
"""

import os
from pathlib import Path

import pandas as pd
import plotly.express as px
import streamlit as st

# ── Page config ───────────────────────────────────────────────────────────────

st.set_page_config(
    page_title="PSA Regional Agricultural Dashboard",
    layout="wide",
    initial_sidebar_state="expanded",
)

DATA_DIR = Path(__file__).parent / "data"

# ── Data loading ──────────────────────────────────────────────────────────────

@st.cache_data
def load_csv() -> tuple[pd.DataFrame, pd.DataFrame]:
    crops = pd.read_csv(DATA_DIR / "crops.csv")
    aqua  = pd.read_csv(DATA_DIR / "aquaculture.csv")
    return crops, aqua


@st.cache_data
def load_parquet() -> tuple[pd.DataFrame, pd.DataFrame]:
    crops = pd.read_parquet(DATA_DIR / "crops.parquet")
    aqua  = pd.read_parquet(DATA_DIR / "aquaculture.parquet")
    return crops, aqua


@st.cache_data
def load_postgis(conn_string: str) -> tuple[pd.DataFrame, pd.DataFrame]:
    from sqlalchemy import create_engine, text

    engine = create_engine(conn_string)
    with engine.connect() as conn:
        crops = pd.read_sql(
            text("SELECT year, region, crop_type, area_ha, production_mt FROM crops"),
            conn,
        )
        aqua = pd.read_sql(
            text("SELECT year, region, farm_type, farm_count, area_ha FROM aquaculture"),
            conn,
        )
    return crops, aqua


# ── Sidebar ───────────────────────────────────────────────────────────────────

with st.sidebar:
    st.title("PSA Agricultural Dashboard")
    st.caption("Philippine Statistics Authority — AFCD")

    st.divider()

    # — Data source selector —
    st.subheader("Data Source")
    source = st.radio(
        "Load data from:",
        options=["CSV", "Parquet", "PostGIS"],
        index=0,
        help=(
            "CSV and Parquet use local files in data/. "
            "PostGIS requires a live DATABASE_URL."
        ),
    )

    if source == "PostGIS":
        conn_str = st.text_input(
            "Connection string",
            value=os.environ.get("DATABASE_URL", "postgresql://user:pass@localhost:5432/psa"),
            type="password",
        )
        load_btn = st.button("Connect", type="primary")
        if load_btn:
            try:
                crops_raw, aqua_raw = load_postgis(conn_str)
                st.session_state["crops_raw"] = crops_raw
                st.session_state["aqua_raw"]  = aqua_raw
                st.success("Connected!")
            except Exception as e:
                st.error(f"Connection failed: {e}")

        crops_raw = st.session_state.get("crops_raw", pd.DataFrame())
        aqua_raw  = st.session_state.get("aqua_raw",  pd.DataFrame())

        if crops_raw.empty:
            st.info("Connect to a PostGIS database to load data.")
            st.stop()
    elif source == "Parquet":
        crops_raw, aqua_raw = load_parquet()
    else:
        crops_raw, aqua_raw = load_csv()

    st.divider()

    # — Filters —
    st.subheader("Filters")

    years_available = sorted(crops_raw["year"].unique())
    selected_year = st.selectbox("Year", ["All"] + years_available)

    regions_available = sorted(crops_raw["region"].unique())
    selected_regions = st.multiselect(
        "Regions",
        options=regions_available,
        default=regions_available,
    )

    crops_available = sorted(crops_raw["crop_type"].unique())
    selected_crops = st.multiselect(
        "Crop types",
        options=crops_available,
        default=crops_available,
    )

# ── Apply filters ─────────────────────────────────────────────────────────────

crops = crops_raw.copy()
aqua  = aqua_raw.copy()

if selected_year != "All":
    crops = crops[crops["year"] == selected_year]
    aqua  = aqua[aqua["year"]  == selected_year]

if selected_regions:
    crops = crops[crops["region"].isin(selected_regions)]
    aqua  = aqua[aqua["region"].isin(selected_regions)]

if selected_crops:
    crops = crops[crops["crop_type"].isin(selected_crops)]

# ── Header ────────────────────────────────────────────────────────────────────

st.title("Regional Agricultural Dashboard")
st.caption(
    f"Philippine Statistics Authority · Agriculture & Fisheries Census Division"
    f" · Source: **{source}**"
    + (f" · Year: **{selected_year}**" if selected_year != "All" else "")
)

if crops.empty:
    st.warning("No data matches the current filters. Adjust the sidebar selections.")
    st.stop()

# ── KPI cards ─────────────────────────────────────────────────────────────────

total_crop_area   = crops["area_ha"].sum()
total_production  = crops["production_mt"].sum()
total_aquafarms   = aqua.loc[aqua["farm_type"] == "Aquafarm",   "farm_count"].sum()
total_seaweed     = aqua.loc[aqua["farm_type"] == "Seaweed Farm","farm_count"].sum()

k1, k2, k3, k4 = st.columns(4)
k1.metric("Total Crop Area",     f"{total_crop_area:,.0f} ha")
k2.metric("Total Production",    f"{total_production:,.0f} mt")
k3.metric("Aquafarms",           f"{int(total_aquafarms):,}")
k4.metric("Seaweed Farms",       f"{int(total_seaweed):,}")

st.divider()

# ── Row 1: area by crop | aquaculture breakdown ───────────────────────────────

col_left, col_right = st.columns([3, 2])

with col_left:
    st.subheader("Harvested Area by Crop Type")
    area_by_crop = (
        crops.groupby("crop_type", as_index=False)["area_ha"]
        .sum()
        .sort_values("area_ha", ascending=False)
    )
    fig_bar = px.bar(
        area_by_crop,
        x="crop_type",
        y="area_ha",
        labels={"crop_type": "Crop", "area_ha": "Area (ha)"},
        color="crop_type",
        color_discrete_sequence=px.colors.qualitative.Safe,
    )
    fig_bar.update_layout(showlegend=False, margin=dict(t=10, b=10))
    st.plotly_chart(fig_bar, use_container_width=True)

with col_right:
    st.subheader("Aquaculture by Farm Type")
    aqua_totals = aqua.groupby("farm_type", as_index=False)["farm_count"].sum()
    fig_pie = px.pie(
        aqua_totals,
        names="farm_type",
        values="farm_count",
        hole=0.45,
        color_discrete_sequence=["#1f77b4", "#2ca02c"],
    )
    fig_pie.update_layout(margin=dict(t=10, b=10))
    st.plotly_chart(fig_pie, use_container_width=True)

# ── Row 2: top regions by crop area ──────────────────────────────────────────

st.subheader("Top Regions by Harvested Area")

top_n = st.slider("Show top N regions", min_value=5, max_value=16, value=10, step=1)

region_crop = (
    crops.groupby(["region", "crop_type"], as_index=False)["area_ha"].sum()
)
top_regions = (
    region_crop.groupby("region")["area_ha"].sum()
    .nlargest(top_n)
    .index.tolist()
)
region_crop_top = region_crop[region_crop["region"].isin(top_regions)]
region_order = (
    region_crop_top.groupby("region")["area_ha"].sum()
    .sort_values(ascending=False)
    .index.tolist()
)

fig_stacked = px.bar(
    region_crop_top,
    x="region",
    y="area_ha",
    color="crop_type",
    labels={"region": "Region", "area_ha": "Area (ha)", "crop_type": "Crop"},
    category_orders={"region": region_order},
    color_discrete_sequence=px.colors.qualitative.Safe,
)
fig_stacked.update_layout(margin=dict(t=10, b=10), xaxis_tickangle=-30)
st.plotly_chart(fig_stacked, use_container_width=True)

# ── Row 3: production vs area scatter ────────────────────────────────────────

st.subheader("Production vs. Harvested Area (by Region & Crop)")

scatter_data = crops.groupby(["region", "crop_type"], as_index=False).agg(
    area_ha=("area_ha", "sum"),
    production_mt=("production_mt", "sum"),
)

fig_scatter = px.scatter(
    scatter_data,
    x="area_ha",
    y="production_mt",
    color="crop_type",
    hover_data=["region"],
    labels={
        "area_ha": "Area (ha)",
        "production_mt": "Production (mt)",
        "crop_type": "Crop",
    },
    color_discrete_sequence=px.colors.qualitative.Safe,
)
fig_scatter.update_layout(margin=dict(t=10, b=10))
st.plotly_chart(fig_scatter, use_container_width=True)

# ── Row 4: summary table ──────────────────────────────────────────────────────

st.subheader("Summary Table")

summary = (
    crops.groupby(["region", "crop_type"], as_index=False)
    .agg(
        Area_ha=("area_ha", "sum"),
        Production_mt=("production_mt", "sum"),
    )
    .sort_values("Area_ha", ascending=False)
    .reset_index(drop=True)
)
summary["Area_ha"]       = summary["Area_ha"].round(1)
summary["Production_mt"] = summary["Production_mt"].round(1)
summary.columns = ["Region", "Crop", "Area (ha)", "Production (mt)"]

st.dataframe(summary, use_container_width=True, height=400)
