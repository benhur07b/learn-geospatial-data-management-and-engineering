"""
Generate dummy PSA agricultural and fisheries data for the dashboard demo.

Outputs (in ../data/):
  crops.csv / crops.parquet
  aquaculture.csv / aquaculture.parquet

Run from the streamlit/ directory:
  python scripts/generate_data.py
"""

import os
import numpy as np
import pandas as pd

SEED = 42
rng = np.random.default_rng(SEED)

OUT_DIR = os.path.join(os.path.dirname(__file__), "..", "data")
os.makedirs(OUT_DIR, exist_ok=True)

# ── Reference tables ──────────────────────────────────────────────────────────

REGIONS = [
    "Ilocos Region",
    "Cagayan Valley",
    "Central Luzon",
    "CALABARZON",
    "MIMAROPA",
    "Bicol Region",
    "Western Visayas",
    "Central Visayas",
    "Eastern Visayas",
    "Zamboanga Peninsula",
    "Northern Mindanao",
    "Davao Region",
    "SOCCSKSARGEN",
    "Caraga",
    "CAR",
    "BARMM",
]

CROPS = [
    "Abaca",
    "Cabbage",
    "Calamansi",
    "Eggplant",
    "Mango",
    "Palay",
    "Sweet Potato",
    "Tobacco",
    "Tomato",
]

YEARS = [2021, 2022, 2023]

# Base area (ha) per region × crop — zero means that crop isn't grown there.
# Rows = regions, columns = crops (same order as CROPS list).
BASE_AREA = {
    #                  Abaca  Cab  Calam  Eggp  Mango  Palay  SwPot  Tob  Tom
    "Ilocos Region":   [   0, 1200,  800, 1500,  9000, 90000,  8000, 12000, 2500],
    "Cagayan Valley":  [   0, 3500,  400, 2000,  3000,150000,  4000, 18000, 4000],
    "Central Luzon":   [   0, 4000,  600, 3000,  5000,200000, 10000,  5000, 6000],
    "CALABARZON":      [1000,  800, 6000, 4000, 12000, 80000,  5000,  1000, 3000],
    "MIMAROPA":        [2500,  300, 3000,  800,  8000, 40000,  3000,   200,  600],
    "Bicol Region":    [18000, 500,  500, 1200,  4000, 60000,  6000,   500, 1000],
    "Western Visayas": [4000,  600, 2000, 2500, 15000,110000,  7000,  2000, 2000],
    "Central Visayas": [1500,  400, 2500, 1800, 10000, 45000,  5000,   800, 1500],
    "Eastern Visayas": [12000, 300,  800, 1000,  3000, 55000,  8000,   300,  800],
    "Zamboanga Peninsula":[3000, 200, 5000, 600,  4000, 35000,  3000,   100,  400],
    "Northern Mindanao":[6000, 1800,  700, 1500,  8000, 75000,  4000,  3000, 2200],
    "Davao Region":    [9000,  600,  400, 1000, 12000, 65000,  5000,   200,  800],
    "SOCCSKSARGEN":    [5000,  500,  300, 1200, 10000, 80000,  4000,   500,  600],
    "Caraga":          [14000, 300,  200,  600,  2000, 30000,  3000,   100,  400],
    "CAR":             [   0, 8000,  100, 3500,   500, 20000, 12000,  4000, 5000],
    "BARMM":           [8000,  200,  800,  500,  3000, 50000,  2000,   100,  300],
}

# Yield (mt/ha) per crop — for computing production_mt
YIELD = {
    "Abaca": 1.2,
    "Cabbage": 15.0,
    "Calamansi": 8.5,
    "Eggplant": 12.0,
    "Mango": 4.5,
    "Palay": 3.8,
    "Sweet Potato": 7.5,
    "Tobacco": 1.1,
    "Tomato": 14.0,
}

# ── Build crops DataFrame ─────────────────────────────────────────────────────

rows = []
for year in YEARS:
    year_factor = 1.0 + (year - 2021) * 0.02  # ~2% annual growth
    for region in REGIONS:
        base_areas = BASE_AREA[region]
        for i, crop in enumerate(CROPS):
            base = base_areas[i]
            if base == 0:
                continue
            # Add ±10% random variation per year
            noise = rng.uniform(0.90, 1.10)
            area = round(base * year_factor * noise, 1)
            production = round(area * YIELD[crop] * rng.uniform(0.92, 1.08), 1)
            rows.append({
                "year": year,
                "region": region,
                "crop_type": crop,
                "area_ha": area,
                "production_mt": production,
            })

crops_df = pd.DataFrame(rows)

# ── Build aquaculture DataFrame ───────────────────────────────────────────────

FARM_TYPES = ["Aquafarm", "Seaweed Farm"]

# Base farm counts per region
BASE_AQUA = {
    #                      Aquafarm  Seaweed
    "Ilocos Region":       (120,  80),
    "Cagayan Valley":      ( 60,  30),
    "Central Luzon":       (400, 150),
    "CALABARZON":          (300, 200),
    "MIMAROPA":            (200, 600),
    "Bicol Region":        (350, 800),
    "Western Visayas":     (500, 400),
    "Central Visayas":     (600, 900),
    "Eastern Visayas":     (250, 700),
    "Zamboanga Peninsula": (180, 1200),
    "Northern Mindanao":   (320, 500),
    "Davao Region":        (280, 600),
    "SOCCSKSARGEN":        (150, 300),
    "Caraga":              (100, 250),
    "CAR":                 ( 20,   5),
    "BARMM":               (400, 1500),
}

# Average area per farm (ha)
AVG_AREA = {"Aquafarm": 2.5, "Seaweed Farm": 1.8}

aqua_rows = []
for year in YEARS:
    year_factor = 1.0 + (year - 2021) * 0.03
    for region in REGIONS:
        counts = BASE_AQUA[region]
        for j, farm_type in enumerate(FARM_TYPES):
            noise = rng.uniform(0.92, 1.08)
            count = max(1, round(counts[j] * year_factor * noise))
            area = round(count * AVG_AREA[farm_type] * rng.uniform(0.90, 1.10), 1)
            aqua_rows.append({
                "year": year,
                "region": region,
                "farm_type": farm_type,
                "farm_count": count,
                "area_ha": area,
            })

aqua_df = pd.DataFrame(aqua_rows)

# ── Write outputs ─────────────────────────────────────────────────────────────

crops_df.to_csv(os.path.join(OUT_DIR, "crops.csv"), index=False)
crops_df.to_parquet(os.path.join(OUT_DIR, "crops.parquet"), index=False)

aqua_df.to_csv(os.path.join(OUT_DIR, "aquaculture.csv"), index=False)
aqua_df.to_parquet(os.path.join(OUT_DIR, "aquaculture.parquet"), index=False)

print(f"Wrote {len(crops_df)} crop rows and {len(aqua_df)} aquaculture rows to {OUT_DIR}/")
print("Files: crops.csv, crops.parquet, aquaculture.csv, aquaculture.parquet")
