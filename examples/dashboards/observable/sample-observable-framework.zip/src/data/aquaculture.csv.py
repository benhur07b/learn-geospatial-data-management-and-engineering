#!/usr/bin/env -S uv run --script
# /// script
# requires-python = ">=3.11"
# dependencies = ["pandas>=2.0", "pyarrow>=12.0", "sqlalchemy>=2.0", "psycopg2-binary"]
# ///
"""
Observable Framework data loader — aquaculture.csv
===================================================
Writes PSA aquaculture data as CSV to stdout.

Selects source via DATA_SOURCE env var:
  csv     (default) — reads ../streamlit/data/aquaculture.csv
  parquet           — reads ../streamlit/data/aquaculture.parquet
  postgis           — queries PostgreSQL at DATABASE_URL
"""

import os
import sys
from pathlib import Path

import pandas as pd

SOURCE = os.environ.get("DATA_SOURCE", "csv").lower()

DATA_DIR = Path(__file__).parents[3] / "streamlit" / "data"

if SOURCE == "parquet":
    df = pd.read_parquet(DATA_DIR / "aquaculture.parquet")

elif SOURCE == "postgis":
    from sqlalchemy import create_engine, text

    engine = create_engine(os.environ["DATABASE_URL"])
    with engine.connect() as conn:
        df = pd.read_sql(
            text("SELECT year, region, farm_type, farm_count, area_ha FROM aquaculture"),
            conn,
        )

else:  # csv (default)
    df = pd.read_csv(DATA_DIR / "aquaculture.csv")

df.to_csv(sys.stdout, index=False)
