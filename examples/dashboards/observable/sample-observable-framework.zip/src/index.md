---
title: PSA Regional Agricultural Dashboard
---

```js
const crops_raw = await FileAttachment("data/crops.csv").csv({typed: true});
const aqua_raw  = await FileAttachment("data/aquaculture.csv").csv({typed: true});
```

<div style="padding: 2rem 0 1.5rem; border-bottom: 1px solid var(--theme-foreground-faint); margin-bottom: 2rem;">
  <div style="font-size: 0.7rem; letter-spacing: 0.15em; text-transform: uppercase; color: var(--theme-foreground-focus); margin-bottom: 0.6rem;">
    Philippine Statistics Authority · AFCD
  </div>
  <h1 style="margin: 0 0 0.4rem; font-size: clamp(1.8rem, 4vw, 2.8rem); line-height: 1.1;">
    Regional Agricultural Dashboard
  </h1>
  <p style="margin: 0; color: var(--theme-foreground-muted); font-size: 0.875rem;">
    Crop area, production &amp; aquaculture statistics across Philippine regions
  </p>
</div>

> **Data source note:** Observable Framework loads data via data loaders at build/dev time. Switch sources with `DATA_SOURCE=csv|parquet|postgis` before `npm run dev`. Filtering is client-side JavaScript — no server round-trips.

---

## Filters

<div class="card">

```js
const yearsList   = ["All", ...[...new Set(crops_raw.map(d => d.year))].sort()];
const regionsList = [...new Set(crops_raw.map(d => d.region))].sort();
const cropsList   = [...new Set(crops_raw.map(d => d.crop_type))].sort();

const filters = view(Inputs.form({
  year:    Inputs.select(yearsList,   {label: "Year",          value: "All"}),
  regions: Inputs.select(regionsList, {label: "Regions",       multiple: true, value: regionsList}),
  crops:   Inputs.select(cropsList,   {label: "Crop types",    multiple: true, value: cropsList}),
  topN:    Inputs.range([3, 16],      {label: "Top N regions", step: 1, value: 10}),
}));
```

</div>

```js
const {year, regions: selRegions, crops: selCrops, topN} = filters;

const crops = crops_raw.filter(d =>
  (year === "All" || d.year === year) &&
  selRegions.includes(d.region) &&
  selCrops.includes(d.crop_type)
);

const aqua = aqua_raw.filter(d =>
  (year === "All" || d.year === year) &&
  selRegions.includes(d.region)
);
```

---

## Overview

```js
const totalArea       = d3.sum(crops, d => d.area_ha);
const totalProduction = d3.sum(crops, d => d.production_mt);
const totalAquafarms  = d3.sum(aqua.filter(d => d.farm_type === "Aquafarm"),     d => d.farm_count);
const totalSeaweed    = d3.sum(aqua.filter(d => d.farm_type === "Seaweed Farm"), d => d.farm_count);

const fmt = (n) => n.toLocaleString("en-PH", {maximumFractionDigits: 0});
```

<div class="grid grid-cols-4">
  <div class="card">
    <div style="font-size: 0.7rem; letter-spacing: 0.12em; text-transform: uppercase; color: var(--theme-foreground-muted); margin-bottom: 0.5rem;">Total Crop Area</div>
    <div style="font-size: 2rem; font-weight: 600; line-height: 1;">${fmt(totalArea)}</div>
    <div style="font-size: 0.8rem; color: var(--theme-foreground-muted); margin-top: 0.25rem;">hectares</div>
  </div>
  <div class="card">
    <div style="font-size: 0.7rem; letter-spacing: 0.12em; text-transform: uppercase; color: var(--theme-foreground-muted); margin-bottom: 0.5rem;">Total Production</div>
    <div style="font-size: 2rem; font-weight: 600; line-height: 1;">${fmt(totalProduction)}</div>
    <div style="font-size: 0.8rem; color: var(--theme-foreground-muted); margin-top: 0.25rem;">metric tons</div>
  </div>
  <div class="card">
    <div style="font-size: 0.7rem; letter-spacing: 0.12em; text-transform: uppercase; color: var(--theme-foreground-muted); margin-bottom: 0.5rem;">Aquafarms</div>
    <div style="font-size: 2rem; font-weight: 600; line-height: 1;">${fmt(totalAquafarms)}</div>
    <div style="font-size: 0.8rem; color: var(--theme-foreground-muted); margin-top: 0.25rem;">registered farms</div>
  </div>
  <div class="card">
    <div style="font-size: 0.7rem; letter-spacing: 0.12em; text-transform: uppercase; color: var(--theme-foreground-muted); margin-bottom: 0.5rem;">Seaweed Farms</div>
    <div style="font-size: 2rem; font-weight: 600; line-height: 1;">${fmt(totalSeaweed)}</div>
    <div style="font-size: 0.8rem; color: var(--theme-foreground-muted); margin-top: 0.25rem;">registered farms</div>
  </div>
</div>

---

## 01 — Crop Overview

```js
const areaByCrop = [...d3.rollup(crops, v => d3.sum(v, d => d.area_ha), d => d.crop_type)]
  .map(([crop_type, area_ha]) => ({crop_type, area_ha}))
  .sort((a, b) => b.area_ha - a.area_ha);

const aquaTotals = [...d3.rollup(aqua, v => d3.sum(v, d => d.farm_count), d => d.farm_type)]
  .map(([farm_type, farm_count]) => ({farm_type, farm_count}));
```

<div class="grid grid-cols-2">
  <div class="card">
    <h3 style="margin: 0 0 0.2rem;">Harvested Area by Crop Type</h3>
    <p style="margin: 0 0 1rem; font-size: 0.8rem; color: var(--theme-foreground-muted);">Total area (ha) planted per crop across all selected regions</p>
    ${resize((width) => Plot.plot({
      width,
      marginBottom: 60,
      x: {label: null, tickRotate: -30},
      y: {label: "Area (ha)", grid: true},
      color: {scheme: "Observable10"},
      marks: [
        Plot.barY(areaByCrop, {x: "crop_type", y: "area_ha", fill: "crop_type", tip: true, sort: {x: "-y"}}),
        Plot.ruleY([0])
      ]
    }))}
  </div>
  <div class="card">
    <h3 style="margin: 0 0 0.2rem;">Aquaculture by Farm Type</h3>
    <p style="margin: 0 0 1rem; font-size: 0.8rem; color: var(--theme-foreground-muted);">Number of registered aquaculture farms</p>
    ${resize((width) => Plot.plot({
      width,
      marginLeft: 120,
      x: {label: "Number of Farms", grid: true},
      y: {label: null},
      color: {scheme: "Tableau10"},
      marks: [
        Plot.barX(aquaTotals, {y: "farm_type", x: "farm_count", fill: "farm_type", tip: true}),
        Plot.ruleX([0])
      ]
    }))}
  </div>
</div>

---

## 02 — Regional Breakdown

```js
const regionTotals = d3.rollup(crops, v => d3.sum(v, d => d.area_ha), d => d.region);
const topRegionNames = [...regionTotals.entries()]
  .sort((a, b) => b[1] - a[1])
  .slice(0, topN)
  .map(([region]) => region);

const regionCropAgg = [...d3.rollup(
  crops.filter(d => topRegionNames.includes(d.region)),
  v => d3.sum(v, d => d.area_ha),
  d => d.region,
  d => d.crop_type
)].flatMap(([region, cropMap]) =>
  [...cropMap].map(([crop_type, area_ha]) => ({region, crop_type, area_ha}))
);
```

<div class="card">
  <h3 style="margin: 0 0 0.2rem;">Top ${topN} Regions by Harvested Area</h3>
  <p style="margin: 0 0 1rem; font-size: 0.8rem; color: var(--theme-foreground-muted);">Stacked by crop type — adjust the Top N slider in the filter panel above</p>
  ${resize((width) => Plot.plot({
    width,
    marginBottom: 80,
    x: {label: null, tickRotate: -30, domain: topRegionNames},
    y: {label: "Area (ha)", grid: true},
    color: {legend: true, scheme: "Observable10"},
    marks: [
      Plot.barY(regionCropAgg, {x: "region", y: "area_ha", fill: "crop_type", tip: true}),
      Plot.ruleY([0])
    ]
  }))}
</div>

---

## 03 — Production vs. Area

```js
const scatterData = [...d3.rollup(
  crops,
  v => ({area_ha: d3.sum(v, d => d.area_ha), production_mt: d3.sum(v, d => d.production_mt)}),
  d => d.region,
  d => d.crop_type
)].flatMap(([region, cropMap]) =>
  [...cropMap].map(([crop_type, {area_ha, production_mt}]) =>
    ({region, crop_type, area_ha, production_mt}))
);
```

<div class="card">
  <h3 style="margin: 0 0 0.2rem;">Harvested Area vs. Production</h3>
  <p style="margin: 0 0 1rem; font-size: 0.8rem; color: var(--theme-foreground-muted);">Each point is a region–crop combination — hover for details</p>
  ${resize((width) => Plot.plot({
    width,
    height: 380,
    x: {label: "Harvested Area (ha)", grid: true},
    y: {label: "Production (mt)", grid: true},
    color: {legend: true, scheme: "Observable10"},
    marks: [
      Plot.dot(scatterData, {
        x: "area_ha", y: "production_mt", fill: "crop_type", r: 5,
        tip: true, channels: {Region: "region"}
      }),
      Plot.frame({opacity: 0.1})
    ]
  }))}
</div>

---

## 04 — Summary Table

```js
const summaryTable = [...d3.rollup(
  crops,
  v => ({
    "Area (ha)":       +d3.sum(v, d => d.area_ha).toFixed(1),
    "Production (mt)": +d3.sum(v, d => d.production_mt).toFixed(1)
  }),
  d => d.region,
  d => d.crop_type
)].flatMap(([region, cropMap]) =>
  [...cropMap].map(([crop_type, vals]) => ({Region: region, Crop: crop_type, ...vals}))
).sort((a, b) => b["Area (ha)"] - a["Area (ha)"]);

display(Inputs.table(summaryTable, {sort: "Area (ha)", reverse: true}));
```
