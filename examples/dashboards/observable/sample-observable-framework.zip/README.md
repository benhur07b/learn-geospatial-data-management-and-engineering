# PSA Regional Agricultural Dashboard — Observable Framework

A BI dashboard for PSA AFCD crop and aquaculture data.
Demonstrates three data-source patterns: **CSV**, **Parquet**, and **PostGIS**.

## Setup

```bash
# 1. Generate the shared data files (only needed once)
cd ../streamlit
uv run python scripts/generate_data.py

# 2. Install npm dependencies
cd ../observable
source ~/.nvm/nvm.sh && nvm use node
npm install

# 3. Start the dev server
npm run dev
```

Open http://localhost:3000 in your browser.

## Data sources

Unlike Streamlit's runtime switcher, Observable Framework loads data at **build/dev time** via data loader scripts. Switch sources by setting `DATA_SOURCE` before starting the server:

| `DATA_SOURCE` | How it works |
|---|---|
| `csv` (default) | `pd.read_csv()` — reads from `../streamlit/data/crops.csv` |
| `parquet` | `pd.read_parquet()` — reads from `../streamlit/data/crops.parquet` |
| `postgis` | `pd.read_sql()` via SQLAlchemy — requires `DATABASE_URL` env var |

```bash
# Example: use Parquet
DATA_SOURCE=parquet npm run dev

# Example: use PostGIS
DATABASE_URL="postgresql://psa:psa@localhost:5432/psa" DATA_SOURCE=postgis npm run dev
```

## How data loaders work

Observable Framework treats `src/data/crops.csv.py` as a **data loader**: it runs the Python
script and caches the CSV output. The dashboard then loads the result with:

```js
const crops = await FileAttachment("data/crops.csv").csv({typed: true});
```

The loaders use **PEP 723 inline script dependencies** (via `uv run --script`), so they are
completely self-contained — no separate Python venv setup required for the Observable project.

## Project structure

```
observable/
  src/
    index.md                # main dashboard (Observable Plot + d3)
    data/
      crops.csv.py          # data loader (Python / PEP 723)
      aquaculture.csv.py    # data loader (Python / PEP 723)
  observablehq.config.js
  package.json
  README.md
```

## Dashboard sections

1. **Filters** — year, regions (multi), crop types (multi), top-N slider
2. **KPI cards** — total crop area, total production, aquafarm count, seaweed farm count
3. **Area by crop** (bar) + **Aquaculture by farm type** (horizontal bar)
4. **Top N regions** stacked bar (reactive to top-N slider)
5. **Production vs. area** scatter (by region & crop, with tooltips)
6. **Summary table** — sortable, paginated
