export default {
  title: "PSA Agricultural Dashboard",
  root: "src",
};
