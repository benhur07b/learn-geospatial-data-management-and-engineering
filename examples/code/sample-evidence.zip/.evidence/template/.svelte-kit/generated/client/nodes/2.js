import * as universal from "../../../../src/pages/explore/+layout.js";
export { universal };
export { default as component } from "../../../../../../node_modules/@sveltejs/kit/src/runtime/components/svelte-4/layout.svelte";