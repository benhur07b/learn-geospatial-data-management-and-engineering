-- PSA aquaculture data — defines the `psa.aquaculture` table.
SELECT * FROM read_csv('../streamlit/data/aquaculture.csv', AUTO_DETECT = TRUE)

-- Parquet alternative:
-- SELECT * FROM read_parquet('../streamlit/data/aquaculture.parquet')
