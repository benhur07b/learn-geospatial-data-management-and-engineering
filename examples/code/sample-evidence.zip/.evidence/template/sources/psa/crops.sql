-- PSA crop data — defines the `psa.crops` table used by dashboard queries.
--
-- Data source options (switch by editing this file):
--
--   CSV (default) — simple, human-readable, works out-of-the-box
SELECT * FROM read_csv('../streamlit/data/crops.csv', AUTO_DETECT = TRUE)

--   Parquet — faster reads, smaller files, exact dtypes preserved
-- SELECT * FROM read_parquet('../streamlit/data/crops.parquet')
--
--   PostGIS — configure a postgres connector instead of duckdb, then:
-- SELECT year, region, crop_type, area_ha, production_mt FROM crops
