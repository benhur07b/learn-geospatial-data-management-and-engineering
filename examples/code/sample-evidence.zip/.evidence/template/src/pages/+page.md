---
title: PSA Regional Agricultural Dashboard
---

# Regional Agricultural Dashboard

_Philippine Statistics Authority · Agriculture & Fisheries Census Division_

**Data source:** Evidence loads data at build time via SQL source files using DuckDB. To switch from CSV to Parquet, edit <code>sources/psa/crops.sql</code>. For PostGIS, configure <code>@evidence-dev/postgres</code> as the connector. This is Evidence's SQL-first philosophy: the query <em>is</em> the data contract.

---

## Filters

```sql years_list
SELECT DISTINCT CAST(year AS VARCHAR) AS year_str
FROM psa.crops
ORDER BY year_str
```

```sql crop_types
SELECT DISTINCT crop_type FROM psa.crops ORDER BY crop_type
```

```sql regions_list
SELECT DISTINCT region FROM psa.crops ORDER BY region
```

<Dropdown data={years_list} name=year value=year_str>
  <DropdownOption value="%" valueLabel="All Years"/>
</Dropdown>

<Dropdown data={crop_types} name=crop_type value=crop_type>
  <DropdownOption value="%" valueLabel="All Crops"/>
</Dropdown>

<Dropdown data={regions_list} name=region value=region>
  <DropdownOption value="%" valueLabel="All Regions"/>
</Dropdown>

<Dropdown name=top_n label="Top N Regions">
  <DropdownOption value=5  valueLabel="Top 5"/>
  <DropdownOption value=10 valueLabel="Top 10"/>
  <DropdownOption value=16 valueLabel="All Regions"/>
</Dropdown>

---

## Overview

```sql kpi
SELECT
  SUM(area_ha)       AS total_area,
  SUM(production_mt) AS total_production
FROM psa.crops
WHERE CAST(year AS VARCHAR) LIKE '${inputs.year.value}'
  AND crop_type                LIKE '${inputs.crop_type.value}'
  AND region                   LIKE '${inputs.region.value}'
```

```sql aqua_kpi
SELECT
  SUM(CASE WHEN farm_type = 'Aquafarm'     THEN farm_count ELSE 0 END) AS aquafarms,
  SUM(CASE WHEN farm_type = 'Seaweed Farm' THEN farm_count ELSE 0 END) AS seaweed_farms
FROM psa.aquaculture
WHERE CAST(year AS VARCHAR) LIKE '${inputs.year.value}'
  AND region                   LIKE '${inputs.region.value}'
```

<BigValue
  data={kpi}
  value=total_area
  title="Total Crop Area"
  fmt=num0
  description="hectares"
/>
<BigValue
  data={kpi}
  value=total_production
  title="Total Production"
  fmt=num0
  description="metric tons"
/>
<BigValue
  data={aqua_kpi}
  value=aquafarms
  title="Aquafarms"
  fmt=num0
  description="registered farms"
/>
<BigValue
  data={aqua_kpi}
  value=seaweed_farms
  title="Seaweed Farms"
  fmt=num0
  description="registered farms"
/>

---

## Crops

```sql area_by_crop
SELECT
  crop_type,
  ROUND(SUM(area_ha), 0) AS area_ha
FROM psa.crops
WHERE CAST(year AS VARCHAR) LIKE '${inputs.year.value}'
  AND crop_type                LIKE '${inputs.crop_type.value}'
  AND region                   LIKE '${inputs.region.value}'
GROUP BY crop_type
ORDER BY area_ha DESC
```

```sql aqua_totals
SELECT
  farm_type,
  SUM(farm_count) AS farm_count
FROM psa.aquaculture
WHERE CAST(year AS VARCHAR) LIKE '${inputs.year.value}'
  AND region                   LIKE '${inputs.region.value}'
GROUP BY farm_type
```

<BarChart
  data={area_by_crop}
  x=crop_type
  y=area_ha
  title="Harvested Area by Crop Type"
  subtitle="Total area (ha) planted per crop across selected regions"
  yAxisTitle="Area (ha)"
  xAxisTitle="Crop"
  sort=y
  sortOrder=desc
/>

<BarChart
  data={aqua_totals}
  x=farm_type
  y=farm_count
  title="Aquaculture by Farm Type"
  subtitle="Number of registered aquaculture farms"
  yAxisTitle="Number of Farms"
  xAxisTitle="Farm Type"
  swapXY=true
/>

---

## Regional Breakdown

```sql region_breakdown
WITH top_regions AS (
  SELECT region, SUM(area_ha) AS total_area
  FROM psa.crops
  WHERE CAST(year AS VARCHAR) LIKE '${inputs.year.value}'
    AND crop_type               LIKE '${inputs.crop_type.value}'
    AND region                  LIKE '${inputs.region.value}'
  GROUP BY region
  ORDER BY total_area DESC
  LIMIT ${inputs.top_n.value}
)
SELECT c.region, c.crop_type, ROUND(SUM(c.area_ha), 0) AS area_ha
FROM psa.crops c
INNER JOIN top_regions r ON c.region = r.region
WHERE CAST(c.year AS VARCHAR) LIKE '${inputs.year.value}'
  AND c.crop_type               LIKE '${inputs.crop_type.value}'
GROUP BY c.region, c.crop_type, r.total_area
ORDER BY r.total_area DESC
```

<BarChart
  data={region_breakdown}
  x=region
  y=area_ha
  series=crop_type
  type=stacked
  title="Top {inputs.top_n.value} Regions by Harvested Area"
  subtitle="Stacked by crop type — use the Top N filter above to adjust"
  yAxisTitle="Area (ha)"
  xAxisTitle="Region"
/>

---

## Production vs. Area

```sql scatter_data
SELECT
  region,
  crop_type,
  ROUND(SUM(area_ha), 0)       AS area_ha,
  ROUND(SUM(production_mt), 0) AS production_mt
FROM psa.crops
WHERE CAST(year AS VARCHAR) LIKE '${inputs.year.value}'
  AND crop_type                LIKE '${inputs.crop_type.value}'
  AND region                   LIKE '${inputs.region.value}'
GROUP BY region, crop_type
```

<ScatterPlot
  data={scatter_data}
  x=area_ha
  y=production_mt
  series=crop_type
  title="Harvested Area vs. Production"
  subtitle="Each point is a region–crop combination. Hover for details."
  xAxisTitle="Harvested Area (ha)"
  yAxisTitle="Production (mt)"
  tooltipTitle=region
/>

---

## Summary Table

```sql summary
SELECT
  region                            AS "Region",
  crop_type                         AS "Crop",
  ROUND(SUM(area_ha), 1)            AS "Area (ha)",
  ROUND(SUM(production_mt), 1)      AS "Production (mt)"
FROM psa.crops
WHERE CAST(year AS VARCHAR) LIKE '${inputs.year.value}'
  AND crop_type                LIKE '${inputs.crop_type.value}'
  AND region                   LIKE '${inputs.region.value}'
GROUP BY region, crop_type
ORDER BY SUM(area_ha) DESC
```

<DataTable
  data={summary}
  search=true
  rows=15
/>
