# PSA Regional Agricultural Dashboard — Evidence

A BI dashboard for PSA AFCD crop and aquaculture data.
Demonstrates three data-source patterns: **CSV**, **Parquet**, and **PostGIS**.

## Setup

```bash
# 1. Generate the shared data files (only needed once)
cd ../streamlit
uv run python scripts/generate_data.py

# 2. Install npm dependencies
cd ../evidence
source ~/.nvm/nvm.sh && nvm use node
npm install

# 3. Run the sources step (loads data into DuckDB cache)
npm run sources

# 4. Start the dev server
npm run dev
```

Open http://localhost:3000 in your browser.

## Data sources

Evidence loads data at **build/source time** via SQL files in `sources/psa/`. To switch sources:

| Source | How to configure |
|--------|-----------------|
| **CSV** (default) | Edit `sources/psa/crops.sql` — uncomment `read_csv(...)` line |
| **Parquet** | Edit `sources/psa/crops.sql` — uncomment `read_parquet(...)` line |
| **PostGIS** | Add a `sources/psa_pg/connection.yaml` with `type: postgres`, then write queries against the live DB |

After changing the source SQL, re-run `npm run sources` to refresh the cache.

### Key architectural difference

Unlike Streamlit and Observable Framework, Evidence is **SQL-first**: the filter dropdowns modify URL parameters, which are interpolated into SQL queries (`${inputs.year.value}`). Every filter change triggers a re-query, not a client-side JS recompute. The data stays in SQL; the page is the report.

## Project structure

```
evidence/
  pages/
    index.md                # main dashboard (SQL + Evidence components)
  sources/
    psa/
      connection.yaml       # DuckDB in-memory connector
      crops.sql             # defines psa.crops table (CSV / Parquet / PostGIS)
      aquaculture.sql       # defines psa.aquaculture table
  evidence.config.yaml      # theme (Ani/Harvest palette) + plugin config
  package.json
  README.md
```

## Dashboard sections

1. **Filters** — Year, Crop Type, Region dropdowns + Top N regions selector
2. **KPI cards** — total crop area, total production, aquafarm count, seaweed farm count
3. **Area by crop** (bar) + **Aquaculture by type** (horizontal bar)
4. **Top N regions** stacked bar (reactive to filter)
5. **Production vs. area** scatter (by region & crop, with tooltips)
6. **Summary table** — searchable, sortable
